# DZKickManager Android

نسخة Android من واجهة المشروع، مهيأة للبناء السحابي عبر GitHub Actions.

## أسرع طريقة من الهاتف
راجع ملف `CLOUD_BUILD.md` ثم:
1. أنشئ GitHub Repository.
2. ارفع محتويات هذا المجلد.
3. افتح Actions > Build Android APK > Run workflow.
4. حمّل Artifact باسم `DZKickManager-debug-apk`.

## البناء المحلي
يتطلب JDK 17 وAndroid SDK وGradle 8.10.2.

> هذه النسخة لا تتضمن منطق إنشاء مشاهدات وهمية أو التلاعب بإحصائيات المنصة.
