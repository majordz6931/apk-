package com.mjr.kickmanager

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private enum class Page { DASHBOARD, SETTINGS, LOGS }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { KickManagerApp(applicationContext) }
    }
}

@Composable
private fun KickManagerApp(context: Context) {
    val prefs = remember { context.getSharedPreferences("dzkickmanager", Context.MODE_PRIVATE) }
    var loggedIn by remember { mutableStateOf(prefs.getBoolean("logged_in", false)) }
    var page by remember { mutableStateOf(Page.DASHBOARD) }
    MaterialTheme {
        if (!loggedIn) LoginScreen {
            prefs.edit().putBoolean("logged_in", true).apply()
            loggedIn = true
        } else {
            MainScreen(page, onPage = { page = it }, onLogout = {
                prefs.edit().putBoolean("logged_in", false).apply()
                loggedIn = false
            })
        }
    }
}

@Composable
private fun LoginScreen(onLogin: () -> Unit) {
    var key by remember { mutableStateOf("") }
    var showKey by remember { mutableStateOf(false) }
    Surface(Modifier.fillMaxSize()) {
        Column(
            Modifier.fillMaxSize().padding(28.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("DZ Kick Manager", style = MaterialTheme.typography.headlineLarge)
            Spacer(Modifier.height(6.dp))
            Text("إدارة ومتابعة القناة", style = MaterialTheme.typography.bodyLarge)
            Spacer(Modifier.height(28.dp))
            OutlinedTextField(
                value = key,
                onValueChange = { key = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("License / Access Key") },
                singleLine = true,
                visualTransformation = if (showKey) androidx.compose.ui.text.input.VisualTransformation.None else PasswordVisualTransformation(),
                trailingIcon = { TextButton(onClick = { showKey = !showKey }) { Text(if (showKey) "إخفاء" else "إظهار") } }
            )
            Spacer(Modifier.height(14.dp))
            Button(onClick = onLogin, Modifier.fillMaxWidth(), enabled = key.isNotBlank()) { Text("دخول") }
            Spacer(Modifier.height(12.dp))
            Text("واجهة Android إدارية. لا تنشئ مشاهدات وهمية.", style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun MainScreen(page: Page, onPage: (Page) -> Unit, onLogout: () -> Unit) {
    Scaffold(
        topBar = { TopAppBar(title = { Text("DZ Kick Manager") }) },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(page == Page.DASHBOARD, { onPage(Page.DASHBOARD) }, icon = {}, label = { Text("الرئيسية") })
                NavigationBarItem(page == Page.SETTINGS, { onPage(Page.SETTINGS) }, icon = {}, label = { Text("الإعدادات") })
                NavigationBarItem(page == Page.LOGS, { onPage(Page.LOGS) }, icon = {}, label = { Text("السجل") })
            }
        }
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            when (page) {
                Page.DASHBOARD -> DashboardScreen()
                Page.SETTINGS -> SettingsScreen(onLogout)
                Page.LOGS -> LogsScreen()
            }
        }
    }
}

@Composable
private fun DashboardScreen() {
    var channel by remember { mutableStateOf("") }
    var running by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("متوقفة") }
    var logs by remember { mutableStateOf(listOf("التطبيق جاهز")) }

    Column(Modifier.fillMaxSize()) {
        Text("لوحة التحكم", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(channel, { channel = it }, Modifier.fillMaxWidth(), label = { Text("اسم القناة") }, singleLine = true)
        Spacer(Modifier.height(16.dp))
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(18.dp)) {
                Text("الحالة: $status", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                Text("الاتصالات النشطة: —")
                Text("الأخطاء: —")
                Text("آخر تحديث: ${SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())}")
                Spacer(Modifier.height(14.dp))
                Button(
                    onClick = {
                        running = !running
                        status = if (running) "تعمل" else "متوقفة"
                        logs = logs + if (running) "تم بدء المهمة" else "تم إيقاف المهمة"
                    },
                    enabled = channel.isNotBlank(),
                    modifier = Modifier.fillMaxWidth()
                ) { Text(if (running) "إيقاف" else "بدء") }
            }
        }
        Spacer(Modifier.height(18.dp))
        Text("آخر الأحداث", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(6.dp))
        logs.takeLast(4).forEach { Text("• $it", Modifier.padding(vertical = 3.dp)) }
    }
}

@Composable
private fun SettingsScreen(onLogout: () -> Unit) {
    var maxConcurrent by remember { mutableStateOf("10") }
    var autoStart by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize()) {
        Text("الإعدادات", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(
            value = maxConcurrent,
            onValueChange = { maxConcurrent = it.filter(Char::isDigit).take(6) },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("Max Concurrent") },
            singleLine = true
        )
        Row(Modifier.fillMaxWidth().padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("بدء تلقائي", Modifier.weight(1f))
            Switch(autoStart, { autoStart = it })
        }
        HorizontalDivider()
        Spacer(Modifier.height(18.dp))
        Text("الاتصال الخارجي", style = MaterialTheme.typography.titleMedium)
        Text("يمكن ربط هذه الواجهة لاحقاً بخدمة/API رسمية ومصرح بها.", style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(24.dp))
        OutlinedButton(onClick = onLogout, modifier = Modifier.fillMaxWidth()) { Text("تسجيل الخروج") }
    }
}

@Composable
private fun LogsScreen() {
    val logs = listOf(
        "Application started",
        "Dashboard ready",
        "Settings loaded",
        "Waiting for an authorized API connection"
    )
    Column(Modifier.fillMaxSize()) {
        Text("سجل النظام", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(12.dp))
        LazyColumn { items(logs) { Text("• $it", Modifier.padding(vertical = 7.dp)) } }
    }
}
